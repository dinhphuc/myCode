﻿#include <stdio.h>
#include <conio.h>
#include <string.h>
#include <Windows.h>
#include "console.h"
#include "menu.h"


int SoSVGioi(HoSo Array[], int n)
{
	int count = 0;
	for (int i = 0; i < n; i++)
	{
		if (Array[i].DiemTB >= 8)
		{
			count++;
		}
			
	}
	return count;
}
int SoSVKha(HoSo Array[], int n)
{
	int count = 0;
	for (int i = 0; i < n; i++)
	{
		if ((Array[i].DiemTB < 8) && ((Array[i].DiemTB >= 6,5)))
		{
			count++;
		}

	}
	return count;
}
int SoSVTB(HoSo Array[], int n)
{
	int count = 0;
	for (int i = 0; i < n; i++)
	{
		if ((Array[i].DiemTB < 6,5) && ((Array[i].DiemTB >=4)))
		{
			count++;
		}

	}
	return count;
}
int SoSVYeu(HoSo Array[], int n)
{
	int count = 0;
	for (int i = 0; i < n; i++)
	{
		if ((Array[i].DiemTB < 4))
		{
			count++;
		}

	}
	return count;
}

void TK_Diem(int Loai, int TongSV)
{

}






////////////////////////////////////////////////////////////
void Menu_ThongKe_DoiMau2(int Toado)
{
	int a = 85;

	gotoxy(a, 8);
	printf("Thong Ke Ti Le SV Gioi");
	gotoxy(a, 10);
	printf("Thong Ke Ti Le SV Kha");
	gotoxy(a, 12);
	printf("Thong Ke Ti Le SV Trung Binh");
	gotoxy(a, 14);
	printf("Thong Ke Ti Le SV yeu");
	gotoxy(a + 5, 17);
	printf("-Thoat-");

	////////////////////////////////////////////////////////////////
	int slep = 10;
	int i;
	for (i = 80; i < 117; i++)
	{
		gotoxy(i, 5);
		printf("%c", 178);

	}
	for (i = 6; i < 20; i++)
	{
		gotoxy(80, i);
		printf("%c", 178);

	}

	// dài dưới
	for (i = 80; i < 117; i++)
	{
		gotoxy(i, 19);
		printf("%c", 178);
	}

	// //RONG
	for (i = 6; i < 20; i++)
	{
		gotoxy(116, i);
		printf("%c", 178);
	}
	///////////////////////////////////////////////////////////////

	

	switch (Toado)
	{
	case 8:
		textcolor(14);
		gotoxy(a, 8);
		printf("Thong Ke Ti Le SV Gioi");
		textcolor(7);
		break;
	case 10:
		textcolor(14);
		gotoxy(a, 10);
		printf("Thong Ke Ti Le SV Kha");
		textcolor(7);
		break;
	case 12:
		textcolor(14);
		gotoxy(a, 12);
		printf("Thong Ke Ti Le SV Trung Binh");
		textcolor(7);
		break;
	case 14:
		textcolor(14);
		gotoxy(a, 14);
		printf("Thong Ke Ti Le SV yeu");
		textcolor(7);
		break;
	case 17:
		textcolor(14);
		gotoxy(a + 5, 17);
		printf("-Thoat-");
		textcolor(7);
		break;
	}

}
void Main_con_ThongKe()
{





}
void Menu_ThongKe_DoiMau1(int ToaDo)
{
	int a = 45;
	gotoxy(a, 8);
	printf("1.Bao Cao So Luong SV Theo Lop");;
	gotoxy(a, 10);
	printf("2. Thong Ke Xep Loai SV");
	gotoxy(a + 5, 12);
	printf("-Thoat-");

	switch (ToaDo)
	{

	case 8:
		textcolor(14);
		gotoxy(a, 8);
		printf("1.Bao Cao So Luong SV Theo Lop");;
		textcolor(7);
		break;
	case 10:
		textcolor(14);
		gotoxy(a, 10);
		printf("2. Thong Ke Xep Loai SV");
		textcolor(7);
		break;
	case 12:
		textcolor(12);
		gotoxy(a + 5, 12);
		printf("-Thoat-");
		textcolor(7);
		break;
	}
}
void Main_ThongKe()
{
	HidePointer();
	HoSo Array[1000];
	input("DSSV.kBz", Array);
	if (TongSoSV() == 0)
	{
		return;
	}
	{
		int x = 0, y = 0, c;
		x = 40, y = 8;
		Menu_batPhim(9);
		Menu_ThongKe_DoiMau1(8);
		while (1)
		{
			fflush(stdin);
			c = _getch();
			switch (c)
			{
			case 80:
				y += 2;
				break;
			case 72:
				y -= 2;
				break;
			}
			if (c == 13)
			{
				switch (y)
				{
				case 8:
					
					break;
				case 10:
					
					break;
				case 12:
					clrscr();
					pain();
					return;
					break;
				}
			}
			if (y > 12)	y = 8;
			if (y < 8) y = 12;
			Menu_ThongKe_DoiMau1(y);
			gotoxy(x, y);
		}
	}

}


