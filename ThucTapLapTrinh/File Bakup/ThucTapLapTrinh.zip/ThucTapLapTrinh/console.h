﻿#pragma once
#include <Windows.h>

void HidePointer();
void ShowPointer();
void gotoxy(int x, int y);
void textcolor(int x);
void pain();
void GioiThieu();
void HuongDan();
void XoaManHinh();
void clrscr();
