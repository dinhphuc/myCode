#include "struct.h"
void SX_Chon_MaLop(HoSo Array[], int n);
void SX_Chen_MaLop(HoSo Array[], int n);
void SX_NoiBot_MaLop(HoSo Array[], int n);
void SX_QuickSort_MaLop(HoSo Array[], int left, int right);


void SX_Chon_MaSV(HoSo Array[], int n);
void SX_Chen_MaSV(HoSo Array[], int n);
void SX_NoiBot_MaSV(HoSo Array[], int n);
void SX_QuickSort_MaSV(HoSo Array[], int left, int right);