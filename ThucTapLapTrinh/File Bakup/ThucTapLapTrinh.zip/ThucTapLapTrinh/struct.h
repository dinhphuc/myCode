#pragma once

struct HoSo{
	char MaLop[25];
	char MaSV[25];
	char Hoten[25];
	char NgaySinh[25];
	float DiemTB;
};

