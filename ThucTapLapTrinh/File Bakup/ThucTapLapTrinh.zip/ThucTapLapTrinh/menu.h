#include "struct.h"
void Main_ThongKe();
void MainSapxep();
void Menu();
int TongSoSV();
void input(char NameFile[], HoSo Array[]);
void ThemMoi_Hs();
void OutPut(HoSo Array[],int n);
void Ong_DaiDuoi(int ChieuDai_duoi_min);
void Ong_ChieuRong(int Ong_RongMin);
void Khung_IN();
void Save();
void Menu_batPhim(int Toado);
void MainTimKiem();