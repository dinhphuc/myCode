﻿#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <conio.h>
#include <string.h>
#include <Windows.h>
#include "console.h"
#include "menu.h"
#include "struct.h"
#include "SapXep.h"

void Menu()
{

	int a = 5;
	system("cls");
	pain();
	gotoxy(a + 6, 3);
	textcolor(252);
	printf("***MENU***");
	textcolor(7);
	//	textcolor(14);
	gotoxy(a, 5);
	printf("1. Them Moi Ho So");
	//	

	gotoxy(a, 6);
	printf("2. In Danh Sach");
	gotoxy(a, 7);
	printf("3. Sap Xep");
	gotoxy(a, 8);
	printf("4. Tim Kiem");
	gotoxy(a, 9);
	printf("5. Thong Ke");
	gotoxy(a, 10);
	printf("6. Thoat");
	gotoxy(a, 5);
}
void Menu_batPhim(int Toado)
{
	int a = 5;
	//	XoaManHinh();
	//	pain();
	gotoxy(a + 6, 3);
	textcolor(415);
	printf("***MENU***");
	textcolor(7);
	gotoxy(a, 5);
	printf("1. Them Moi Ho So");
	gotoxy(a, 6);
	printf("2. In Danh Sach");
	gotoxy(a, 7);
	printf("3. Sap Xep");
	gotoxy(a, 8);
	printf("4. Tim Kiem");
	gotoxy(a, 9);
	printf("5. Thong Ke");
	gotoxy(a, 10);
	printf("6. Thoat");
	gotoxy(a, 5);

	switch (Toado)
	{
	case 5:
		textcolor(14);
		gotoxy(a, 5);
		printf("1. Them Moi Ho So");
		textcolor(7);
		break;
	case 6:
		textcolor(14);
		gotoxy(a, 6);
		printf("2. In Danh Sach");
		textcolor(7);
		break;
	case 7:

		textcolor(14);
		gotoxy(a, 7);
		printf("3. Sap Xep");
		textcolor(7);
		break;
	case 8:
		textcolor(14);
		gotoxy(a, 8);
		printf("4. Tim Kiem");
		textcolor(7);
		break;
	case 9:
		textcolor(14);
		gotoxy(a, 9);
		printf("5. Thong Ke");
		textcolor(7);
		break;
	case 10:
		textcolor(12);
		gotoxy(a, 10);
		printf("6. Thoat");
		textcolor(7);
		break;
	}

}
void main()
{

	
	HoSo Array[1000];
	_getch();
	HidePointer();
	Menu();
	// Bắt Phím
	{
		int x = 0, y = 0, c;
		x = 5, y = 5;
		Menu_batPhim(5);
		while (1)
		{
			
			
			c = _getch();
			switch (c)
			{
			case 80:
				y++;
				break;
			case 72:
				y--;
				break;
			}
			if (c == 13)
			{
				switch (y)
				{
				case 5:
					ThemMoi_Hs();
					clrscr();
					Menu();
					break;

				case 6:
					clrscr();
					input("DSSV.kBz", Array);
					OutPut(Array, TongSoSV());
					Menu();
					break;
				case 7:
					MainSapxep();
					break;
				case 8:
					MainTimKiem();
					break;
				case 9:
					Main_ThongKe();
					break;
				case 10:
					return;
					break;
				}
			}
			if (y > 10)	y = 5;
			if (y < 5) y = 10;
			Menu_batPhim(y);
			gotoxy(x, y);
		}
	}
}