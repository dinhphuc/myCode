﻿#define _CRT_SECURE_NO_WARNINGS
#include "menu.h"
#include <stdio.h>
#include <conio.h>
#include <Windows.h>
#include "console.h"
#include "struct.h"

long size = sizeof(HoSo);


void Menu_ThemHS()
{
	int a = 50;
	/***************************************/
	/*Nhập Mã  Lớp*/
	textcolor(192);
	gotoxy(a, 5);
	printf("    Ma Lop:     ");

	gotoxy(a + 17, 5);
	textcolor(255);
	printf("                       ");

	/*Nhập Mã  SV*/
	gotoxy(a, 7);
	textcolor(192);
	printf("     MaSV:      ");

	gotoxy(a + 17, 7);
	textcolor(255);
	printf("                       ");

	/*Nhập Họ  Tên*/
	gotoxy(a, 9);
	textcolor(192);
	printf("  Ho va Ten:    ");

	gotoxy(a + 17, 9);
	textcolor(255);
	printf("                       ");

	/*Nhập Ngày Sinh*/
	gotoxy(a, 11);
	textcolor(192);
	printf("   Ngay Sinh:   ");

	gotoxy(a + 17, 11);
	textcolor(255);
	printf("                       ");

	/*Nhập Điểm TB*/
	gotoxy(a, 13);
	textcolor(192);
	printf("Diem Trung Binh:");
	gotoxy(a + 17, 13);
	textcolor(255);
	printf("                       ");
	textcolor(7);
	/**************************************/
}
void  ThemMoi_Hs()
{

	HoSo SV;
	FILE *fp;
	fp = fopen("DSSV.kBz", "a+b"); // mở file Ghi Thêm "a+b"
	int a = 50;
	int c;
	int Dem = 1;

	ShowPointer(); // Hiện con trỏ
	
	do{
		gotoxy(a + 30, 3);
		printf("(Ban Dang Nhap Thong Tin HoSo: %d)", Dem);
		Menu_ThemHS();
		gotoxy(a, 5);
		fflush(stdin);

		/*Nhập Mã  Lớp*/
		textcolor(192);
		printf("    Ma Lop:     ");
		textcolor(249);
		gotoxy(a + 18, 5);
		gets(SV.MaLop);
		fflush(stdin);
		/*Nhập Mã  SV*/
		do
		{

			gotoxy(a, 7);
			textcolor(192);
			printf("     MaSV:     ");
			textcolor(249);
			gotoxy(a + 18, 7);
			gets(SV.MaSV);
			fflush(stdin);
			if (strlen(SV.MaSV) != 8)
			{
				gotoxy(85, 7);
				textcolor(14);
				printf("ERRO ! Vui Long Nhap 8 So");
				gotoxy(a + 17, 7);
				textcolor(255);
				printf("                       ");

			}
		} while (strlen(SV.MaSV) != 8);
		textcolor(7);
		gotoxy(90, 7);
		printf("                             ");

		/*Nhập Họ Và Tên*/
		gotoxy(a, 9);
		textcolor(192);
		printf("  Ho va Ten:    ");
		textcolor(249);
		gotoxy(a + 18, 9);
		gets(SV.Hoten);
		fflush(stdin);


		/*Nhập Ngày Sinh*/
		gotoxy(a, 11);
		textcolor(192);
		printf("   Ngay Sinh:   ");
		textcolor(249);
		gotoxy(a + 18, 11);
		gets(SV.NgaySinh);


		/*Nhập Điểm  TB*/
		gotoxy(a, 13);
		textcolor(192);
		printf("Diem Trung Binh:");

		gotoxy(a + 18, 13);
		do
		{
			textcolor(249);
			gotoxy(a+18, 13);
			scanf("%f", &SV.DiemTB);
			if (SV.DiemTB > 10.0 || SV.DiemTB <0.0)
			{
				textcolor(14);
				gotoxy(a+45, 13);
				printf("ERRO !");
				gotoxy(a + 17, 13);
				textcolor(255);
				printf("                       ");
			}
		} while (SV.DiemTB >10.0 || SV.DiemTB < 0.0);
		textcolor(7);
		gotoxy(a+45, 13);
		printf("                  ");

		////////////////////////////////////////////////////////////////////
		fwrite(&SV, size, 1, fp); // ghi file Nhị Phân
		///////////////////////////////////////////////////////////////////
		gotoxy(a, 15);
		printf("1.Nhap Tiep (Enter)\t2.Cancel(ESC)");
		c = _getch();
		clrscr();
		textcolor(7);
		Dem++;
	} while (c == 13);
	fclose(fp);
	HidePointer();

}
void Save()
{
	char c = 205;  //ống Ngang
	char d = 186;  // ống dọc
	char c1 = 201; // góc trái trên
	char c2 = 200; // góc trái dưới
	char c3 = 187; // góc phải trên 
	char c4 = 188; // góc phải dưới
	char c5 = 202; // Ống căm lên
	char c6 = 203; // ống cắm xuống
	char c7 = 206; // ống Dấu cộng

	gotoxy(0, 0);
	int i;
	textcolor(244);
	//Ống Bên Chiều Dài Trên t
	for (i = 50; i < 100; i++)
	{
		gotoxy(i, 9);
		printf("%c", c);

	}
	gotoxy(1, 2); printf("%c", c1);
	gotoxy(120, 2); printf("%c", c3);
	//Ống Bên Chiều Dài Dưới 
	for (i = 51; i < 100; i++)
	{
		gotoxy(i, 15);
		printf("%c", c);

	}
	gotoxy(50, 9); printf("%c", c1);
	gotoxy(100, 9); printf("%c", c3);
	/// Ống Bên Chiều rộng
	for (i = 10; i < 15; i++)
	{
		gotoxy(50, i);
		printf("%c", d);

	}
	for (i = 10; i < 15; i++)
	{
		gotoxy(100, i);
		printf("%c", d);
	}
	gotoxy(50, 15); printf("%c", c2);
	gotoxy(100, 15); printf("%c", c4);

	/*********** Bên Trong*************/

	gotoxy(66, 10); printf("Them Vao Danh Sach");
	/********YES*******/
	for (i = 54; i < 62; i++)
	{
		gotoxy(i, 12);
		printf("%c", c);
	}
	gotoxy(54, 12); printf("%c", c1);
	gotoxy(62, 12); printf("%c", c3);

	gotoxy(54, 13);
	printf("%c  YES  %c", d, d);

	for (i = 54; i < 62; i++)
	{
		gotoxy(i, 14);
		printf("%c", c);
	}
	gotoxy(54, 14); printf("%c", c2);
	gotoxy(62, 14); printf("%c", c4);


	/********NO*******/
	gotoxy(88, 12);
	for (i = 88; i < 96; i++)
	{
		gotoxy(i, 12);
		printf("%c", c);
	}
	gotoxy(88, 12); printf("%c", c1);
	gotoxy(96, 12); printf("%c", c3);

	gotoxy(88, 13); printf("%c  NO   %c", d, d);

	for (i = 88; i < 96; i++)
	{
		gotoxy(i, 14);
		printf("%c", c);
	}
	gotoxy(88, 14); printf("%c", c2);
	gotoxy(96, 14); printf("%c", c4);
	/*       màu nền   */
	gotoxy(51, 10); printf("               "); gotoxy(84, 10); printf("                ");
	gotoxy(51, 11); printf("                                                 ");
	gotoxy(51, 12); printf("   ");	gotoxy(63, 12); printf("                         ");	gotoxy(97, 12); printf("   ");
	gotoxy(51, 13); printf("   ");  gotoxy(63, 13); printf("                         ");	gotoxy(97, 13); printf("   ");
	gotoxy(51, 14); printf("   "); gotoxy(63, 14); printf("                         "); gotoxy(97, 14); printf("   ");



	textcolor(7);

}