#include <stdio.h>
#include <conio.h>
#include <math.h>

int TinhGiaThua(int n)
{
	int i;
	int s = 1;
	for ( i = 1; i <=n; i++)
	
		s *= i;
	return s;
}

void TinhToHop(int n , int k)
{
	int ToHop;
	ToHop = TinhGiaThua(n) / ((TinhGiaThua(k))*TinhGiaThua(n - k));
	printf("\n%d", ToHop);
}
void main()
{
	int k, n;
	printf("Nhap To Hop Chap K cua N ( n < k ) \n");
	do{
		printf("Nhap k= ");
		scanf_s("%d", &k);
		printf("Nhap n= ");
		scanf_s("%d", &n);
	} while (n < k);

	TinhToHop(n, k);

	_getch();
}